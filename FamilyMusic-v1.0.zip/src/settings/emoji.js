module.exports = {
    button: {
      pause: "<:music_pause:1201252343883251732>",
      resume: "<:music_resume:1201252420194422874>",
      stop: "<:music_stop:1201252486250508378>",
      skip: "<:skip:1201252549974573208>",
      previous: "<:previous:1201252611085570048>",
      replay: "<:expReplay:1201252676571242616>",
      voldown: "<:volume_down:1201252752446201887>",
      volup: "<:volume_up:1201252836818821130>",
      shuffle: "<:shuffle:1201252899783708704>",
      info: "<:info:1201252979299324044>",
      loop: {
        none: "<:loopp:1201253032999010467>",
        track: "🔂",
        queue: "<:queue:1201253104482533429>",
      },
    },
  
    queue: {
      back: "<:back:1201253156575785042>",
      next: "<:next:1201253208841011200>",
      cancel: "<:icon_cross:1201253258749030440>",
    },
  };
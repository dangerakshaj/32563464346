module.exports.run = async (client, player) => {
    console.log(`[DEBUG] Player Created from (${player.guildId})`);
};

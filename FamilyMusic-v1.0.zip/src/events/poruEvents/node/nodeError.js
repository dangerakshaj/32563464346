module.exports.run = (client, node, error) => {
    console.log(`[ERROR] Node ${node.name} Error!`);
};

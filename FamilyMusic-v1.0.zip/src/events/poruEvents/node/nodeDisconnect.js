module.exports.run = (client, node) => {
    console.log(`[WARN] Node ${node.name} Disconnected!`);
};

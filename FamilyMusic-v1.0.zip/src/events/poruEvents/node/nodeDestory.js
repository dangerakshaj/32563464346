module.exports.run = (client, node, error) => {
    console.log(`[INFO] Node ${node.name} Destroyed!`);
};

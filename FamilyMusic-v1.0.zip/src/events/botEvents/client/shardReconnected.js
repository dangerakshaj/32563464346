module.exports.run = async (client, error, id) => {
    console.log(`[WARN] Shard ${id} Shard Reconnected!`);
};

module.exports.run = async (client, error, id) => {
    console.log(`[ERROR] Shard ${id} Shard Errored!`);
};

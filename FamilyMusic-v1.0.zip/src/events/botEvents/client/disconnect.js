module.exports.run = async (client) => {
    console.log(`[WARN] Disconnected ${client.user.tag} (${client.user.id})`);
};

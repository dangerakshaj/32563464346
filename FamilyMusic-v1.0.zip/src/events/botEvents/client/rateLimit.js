module.exports.run = async (client, info) => {
    console.log(`[ERROR] Rate Limited, Sleeping for ${0} seconds!`);
};

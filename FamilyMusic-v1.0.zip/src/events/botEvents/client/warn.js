module.exports.run = async (client) => {
    console.log(`[WARN] Warned ${client.user.tag} (${client.user.id})`);
};

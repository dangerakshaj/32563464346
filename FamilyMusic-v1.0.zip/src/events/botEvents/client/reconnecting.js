module.exports.run = async (client) => {
    console.log(`[WARN] Reconnected ${client.user.tag} (${client.user.id})`);
};

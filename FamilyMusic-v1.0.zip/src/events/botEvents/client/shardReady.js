module.exports.run = async (client, id) => {
    console.log(`[INFO] Shard ${id} Ready!`);
};
